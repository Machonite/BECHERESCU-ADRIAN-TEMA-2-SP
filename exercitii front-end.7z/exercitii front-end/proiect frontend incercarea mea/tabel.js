function Angajat(nume, varsta, departament, proiect, Data_angajarii){
    this.nume = nume;
    this.varsta = varsta;
    this.departament = departament;
    this.proiect = proiect;
    this.Data_angajarii = Data_angajarii;
    this.vizualizare ="<a href='angajat.html'>Vizualizare<a/>"
};

const Angajati = [new Angajat("Sandulescu Bogdan",22,"QA","Tester","24.03.2020"),new Angajat("Sandulescu Alex",22,"QA","Tester","24.03.2020"),new Angajat("Sandulescu Bogdan",22,"QA","Tester","24.03.2020")];
console.log(Angajati);
    
const table = document.querySelector("table");


function adaugare(angajatNou){
    /*const newRow = document.createElement("tr");
    const newData1 = document.createElement("td");
    const newData2 = document.createElement("td");
    const newData3 = document.createElement("td");
    const newData4 = document.createElement("td");
    const newData5 = document.createElement("td");
    const newData6 = document.createElement("td");

    newData1.innerHTML = angajatNou.nume;
    newData2.innerHTML = angajatNou.varsta;
    newData3.innerHTML = angajatNou.departament;
    newData4.innerHTML = angajatNou.proiect;
    newData5.innerHTML = angajat.Data_angajarii;
    newData6.innerHTML = "<a href ='angajat.html'>Vizualizare</a>";

    newRow.appendChild(newData1);
    newRow.appendChild(newData2);
    newRow.appendChild(newData3);
    newRow.appendChild(newData4);
    newRow.appendChild(newData5);
    newRow.appendChild(newData6);

*/
    const newRow = document.createElement("tr");
    const convertArray = Object.values(angajatNou);
    

    for(let i =0; i<6;i++)
    {
        const newData = document.createElement("td");
        newData.innerHTML = convertArray[i];
        newRow.appendChild(newData);
    }
    table.appendChild(newRow);
}
adaugare(Angajati[0]);
adaugare(Angajati[1]);
//adaugare(Angajati[2]);

function stergereAngajat(angajatdeSters){

}

function addOnClick(){
    const newRow = document.createElement("tr");
    const convertArray = Object.values(angajatNou);
    


}






