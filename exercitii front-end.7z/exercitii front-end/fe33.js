function hello() {
    console.log('hello function received', arguments);

}
const world =() => {
    console.log('world function received', arguments);
}

hello('hello','world');

