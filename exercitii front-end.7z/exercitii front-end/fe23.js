//const obj = [1,2,3,4];

//function doStuff(param){
 //   const newArray = param.slice(0);
 //   param[0]= 10;
 //   console.log(NewArray);

//}
//

//doStuff(newArray);

//console.log(obj);

function add(a,b) {
    return a+b;
}
const history =[];
function add(a,b)
{
    history.push(['add',a,b,a+b]);
    return a+b;
}

const a =1;
const b=2;
console.log(add(a,b));
console.log(add(4,5));

console.log(history);
