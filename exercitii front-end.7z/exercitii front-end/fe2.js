function createLogger(loggerName)
{
    //const messages = [];
    return function(message){
        messages.push(message);
        console.log('[${loggerName}] ${message}');
}
};

const log = createLogger('My Logger');
log('hello');

const myName = 'John';
function hello(){
    console.log(myName);
}
hello();
