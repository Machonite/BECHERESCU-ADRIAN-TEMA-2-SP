package com.example.raiff;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController
public class AngajatController {
    @Autowired
    AngajatService angajatService;

    @Autowired
    AngajatRepository angajatRepository;
    @GetMapping("/angajat")
    public ResponseEntity<List<Angajat>> getAngajatieWithProiecte() {
        List<Angajat> angajat = angajatRepository.getAllAngajat();
        if (angajat == null) {
            return ResponseEntity.notFound().build();
// return null;
        }
        return ResponseEntity.ok(angajat);
    }

    @GetMapping("/angajat/{angajatid}")
    private Angajat getAngajat(@PathVariable("angajatid") Long angajatid){
        return angajatService.getAngajatById(angajatid);
    }

    @DeleteMapping("/angajat/{angajatid}")
    private void deleteAngajat(@PathVariable("angajatid")Long angajatid)
    {
        angajatService.delete(angajatid);
    }

    @PostMapping("/angajat")
    private Long saveAngajat(@RequestBody Angajat angajat){
        angajatService.saveOrUpdate(angajat);
        return angajat.getAngajatId();

    }

    @PutMapping("/angajat")
    private Angajat update(@RequestBody Angajat angajat){
        angajatService.saveOrUpdate(angajat);
        return angajat;
    }
}
