package com.example.raiff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RaiffApplication {

	public static void main(String[] args) {
		SpringApplication.run(RaiffApplication.class, args);
	}

}
