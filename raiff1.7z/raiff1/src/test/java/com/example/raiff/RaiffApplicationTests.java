package com.example.raiff;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RaiffApplicationTests {

	@Test
	void contextLoads() {
	}

}
